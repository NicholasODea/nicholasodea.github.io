import asyncio
import traceback


async def _show_startup_error(exc: Exception) -> None:
    traceback.print_exc()
    try:
        import pygame
    except Exception:
        return

    pygame.init()
    screen = pygame.display.set_mode((920, 660))
    clock = pygame.time.Clock()
    message = "".join(traceback.format_exception_only(type(exc), exc)).strip() or repr(exc)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return

        screen.fill((42, 45, 52))
        pygame.draw.rect(screen, (255, 235, 220), pygame.Rect(72, 72, 560, 150), width=4)
        try:
            font = pygame.font.Font(None, 30)
            title_font = pygame.font.Font(None, 46)
            screen.blit(title_font.render("Paths failed to start", True, (255, 235, 220)), (96, 96))
            screen.blit(font.render(message[:100], True, (255, 235, 220)), (96, 156))
        except Exception:
            pygame.draw.rect(screen, (255, 235, 220), pygame.Rect(96, 96, 260, 24))
        pygame.display.flip()
        clock.tick(30)
        await asyncio.sleep(0)


async def main() -> None:
    try:
        from pathgame.ui import run_async

        await run_async()
    except Exception as exc:
        await _show_startup_error(exc)


asyncio.run(main())
