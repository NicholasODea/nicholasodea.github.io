\# Paths project instructions for Codex



This project implements a two-player tile-placement path game.



\## Main rule



Keep the rules engine separate from the UI. The UI must call the core engine and must not duplicate rule logic.



Use Python 3.11+. Prefer `pygame-ce` for the graphical version.



\## Desired layout



```text

main.py

pathgame/

&#x20;   \_\_init\_\_.py

&#x20;   core.py

&#x20;   graphics.py

&#x20;   ui.py

README.md

```



\## Game rules



Board:



\* 6 x 6 square grid.

\* Coordinates are `(row, col)`.

\* Periodic boundary conditions in both directions, so the board is a flat torus.

\* Starting location `SL = (4, 4)`.

\* Ending location `EL = (1, 1)`.

\* SL and EL both start with tile D already placed.



Directions:



\* Use N, E, S, W.



Tiles:



\* Tiles cannot rotate.

\* Both players see the same board orientation.

\* A connects N-E and S-W.

\* B connects N-W and S-E.

\* C has all four ports open, but connects none internally. It terminates paths that enter it.

\* D has all four ports open and mutually connected, like a cross.



Player tile cycles:



\* Maker repeats: B, A, D.

\* Diverter repeats: A, B, A, B, C.

\* The current player’s tile is forced by their own personal turn count.

\* Neither player can pass.



Placement:



\* A move places the current player’s forced tile on an empty cell.

\* A tile may be placed only if, after placement, at least one open port of that tile connects to an open port of a neighboring already-placed tile in the connected component containing SL.

\* Connectivity must respect tile internal connections and torus neighbor wrapping.

\* C has open ports, so it can be placed adjacent to the SL-connected component, but because it has no internal connections, it terminates paths.



Win conditions:



\* Maker wins immediately when SL connects to EL.

\* Diverter wins if the board fills and SL is still not connected to EL.

\* Diverter also wins if the current player has no legal move and Maker has not already won.



\## Core API



Implement these in `pathgame/core.py`:



```python

new\_game() -> GameState

legal\_actions(state: GameState) -> list\[Action]

apply\_action(state: GameState, action: Action) -> GameState

winner(state: GameState) -> Winner | None

is\_terminal(state: GameState) -> bool

forced\_tile\_for\_current\_player(state: GameState) -> TileKind

```



Use dataclasses/enums/type hints for game objects.



\## Graphical UI



Build a clickable pygame UI.



Requirements:



\* Draw a 6 x 6 board with row and column labels.

\* Draw tiles as actual graphics using pygame drawing commands, not ASCII.

\* Generate tile images procedurally; do not use external image files yet.

\* Let players click a cell to place the current forced tile.

\* Reject illegal moves with a visible explanation.

\* Show current player, current tile, previous tile, Maker cycle, and Diverter cycle.

\* Highlight the current tile in the current player’s cycle; use tile images.

\* Highlight the previous tile in the other player’s cycle; use tile images.

\* Draw SL and EL as D tiles with S and E in the center.

\* Add controls:



&#x20; \* `z` = undo

&#x20; \* `r` = reset

&#x20; \* `q` or Escape = quit



\## Tile graphics



Use square tile images with ports at the midpoint of each side.



Visual intent:



\* A should look like two parallel `\\` paths:



&#x20; \* N to E

&#x20; \* S to W

\* B should look like two parallel `/` paths:



&#x20; \* N to W

&#x20; \* S to E

\* C should show four disconnected stubs.

\* D should show a four-way cross.



Implement something like:



```python

make\_tile\_surface(tile\_kind: TileKind, size: int, label: str | None = None) -> pygame.Surface

```



For SL and EL:



\* Draw tile D.

\* Put `S` or `E` at the center.



\## Move history and undo



Maintain a move history list. Each record should include:



\* move number

\* player

\* tile

\* coordinate

\* state before

\* state after



Undo should remove the last move and restore the previous state.



\## Run commands



Install dependency:



```bash

pip install pygame-ce

```



Run game:



```bash

python main.py

```



\## Acceptance criteria



A task is complete when:



\* `python main.py` opens a playable clickable game window.

\* Legal clicks place the correct forced tile.

\* Illegal clicks are rejected with an explanation.

\* The forced tile sequences are correct.

\* SL and EL start as D tiles at `(4,4)` and `(1,1)`.

\* Maker wins immediately when SL connects to EL.

\* Diverter wins when appropriate.

\* Undo works.

\* Reset works.

\* Core rules are separate from UI code.




## Git and GitHub workflow

Use Git for every nontrivial change.

Before editing:
1. Run `git status`.
2. If there are uncommitted user changes, stop and ask what to do.
3. Create a new branch for substantial work using a descriptive name.

During work:
1. Keep changes focused on the requested task.
2. Do not mix unrelated refactors into feature work.
3. Do not delete user files unless explicitly asked.
4. Run the relevant checks after changes.

After work:
1. Run `git status`.
2. Summarize the important diff.
3. Commit the completed change with a clear message.
4. Push the branch to GitHub.
5. Tell me the branch name and the commit hash.

For feature work, prefer pushing a branch rather than pushing directly to main.

Do not force-push unless I explicitly ask.
Do not overwrite remote work.
Do not store secrets, tokens, API keys, or credentials in the repo.
