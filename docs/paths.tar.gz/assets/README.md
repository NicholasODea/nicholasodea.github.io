# Paths

Two-player tile-placement path game on a 6 x 6 torus.

## Run

```bash
pip install pygame-ce
python main.py
```

On this Windows machine, if `python` is not on PATH yet, run:

```bat
run_paths.bat
```

To verify the available Python and pygame runtime without opening the game window:

```bat
run_paths.bat --check
```

## Browser

Use pygbag to run the pygame version in a browser:

```bash
pip install -r requirements-web.txt
python -m pygbag .
```

Then open the local URL printed by pygbag, usually `http://localhost:8000/`.

To build the static web files:

```bash
python -m pygbag --build .
```

The generated webpage is written under `build/web/`.

## Controls

- Click an empty legal cell to place the current player's forced tile.
- `z`: undo
- `r`: reset
- `q` or Escape: quit

The rules engine lives in `pathgame/core.py`; the pygame interface lives in `pathgame/ui.py`.
