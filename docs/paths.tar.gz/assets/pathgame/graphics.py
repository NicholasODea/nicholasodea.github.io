from __future__ import annotations

import pygame

from pathgame.core import TileKind


BG = (246, 244, 239)
TILE_BG = (255, 252, 244)
TILE_EDGE = (70, 74, 82)
PATH = (29, 120, 132)
PATH_SHADOW = (16, 69, 78)
TEXT = (30, 34, 40)
STUB = (154, 78, 68)


def make_tile_surface(tile_kind: TileKind, size: int, label: str | None = None) -> pygame.Surface:
    surface = pygame.Surface((size, size), pygame.SRCALPHA)
    rect = pygame.Rect(0, 0, size, size)
    pygame.draw.rect(surface, TILE_BG, rect, border_radius=max(4, size // 12))
    pygame.draw.rect(surface, TILE_EDGE, rect.inflate(-1, -1), width=max(2, size // 28), border_radius=max(4, size // 12))

    margin = size * 0.18
    center = size // 2
    north = (center, 0)
    east = (size, center)
    south = (center, size)
    west = (0, center)
    inner_n = (center, margin)
    inner_e = (size - margin, center)
    inner_s = (center, size - margin)
    inner_w = (margin, center)
    width = max(8, size // 7)
    shadow_width = width + max(2, size // 28)

    def line(points: list[tuple[float, float]]) -> None:
        pygame.draw.lines(surface, PATH_SHADOW, False, points, shadow_width)
        pygame.draw.lines(surface, PATH, False, points, width)

    def stub(start: tuple[float, float], end: tuple[float, float]) -> None:
        pygame.draw.line(surface, PATH_SHADOW, start, end, shadow_width)
        pygame.draw.line(surface, STUB, start, end, width)
        pygame.draw.circle(surface, STUB, end, max(3, width // 3))

    if tile_kind is TileKind.A:
        line([north, inner_n, inner_e, east])
        line([south, inner_s, inner_w, west])
    elif tile_kind is TileKind.B:
        line([north, inner_n, inner_w, west])
        line([south, inner_s, inner_e, east])
    elif tile_kind is TileKind.C:
        stub(north, inner_n)
        stub(east, inner_e)
        stub(south, inner_s)
        stub(west, inner_w)
    elif tile_kind is TileKind.D:
        line([north, (center, center), south])
        line([west, (center, center), east])
        pygame.draw.circle(surface, PATH, (center, center), width // 2)

    if label:
        font = pygame.font.Font(None, int(size * 0.48))
        text = font.render(label, True, TEXT)
        text_rect = text.get_rect(center=(center, center))
        pad = max(4, size // 16)
        badge = text_rect.inflate(pad * 2, pad)
        pygame.draw.rect(surface, (255, 252, 244), badge, border_radius=pad)
        pygame.draw.rect(surface, TILE_EDGE, badge, width=2, border_radius=pad)
        surface.blit(text, text_rect)

    return surface
