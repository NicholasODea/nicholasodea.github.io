"""Paths tile-placement game package."""

