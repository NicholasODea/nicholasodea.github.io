from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from enum import Enum
from typing import Iterable


BOARD_SIZE = 6
SL = (4, 4)
EL = (1, 1)


class Direction(Enum):
    N = "N"
    E = "E"
    S = "S"
    W = "W"


class TileKind(Enum):
    A = "A"
    B = "B"
    C = "C"
    D = "D"


class Player(Enum):
    MAKER = "Maker"
    DIVERTER = "Diverter"


class Winner(Enum):
    MAKER = "Maker"
    DIVERTER = "Diverter"


Coord = tuple[int, int]
Board = tuple[tuple[TileKind | None, ...], ...]


@dataclass(frozen=True)
class Action:
    row: int
    col: int

    @property
    def coord(self) -> Coord:
        return (self.row, self.col)


@dataclass(frozen=True)
class GameState:
    board: Board
    current_player: Player
    maker_turn_count: int
    diverter_turn_count: int


MAKER_CYCLE = (TileKind.B, TileKind.A, TileKind.D)
DIVERTER_CYCLE = (TileKind.A, TileKind.B, TileKind.A, TileKind.B, TileKind.C)

OFFSETS = {
    Direction.N: (-1, 0),
    Direction.E: (0, 1),
    Direction.S: (1, 0),
    Direction.W: (0, -1),
}

OPPOSITE = {
    Direction.N: Direction.S,
    Direction.E: Direction.W,
    Direction.S: Direction.N,
    Direction.W: Direction.E,
}

ALL_PORTS = frozenset(Direction)

TILE_CONNECTIONS: dict[TileKind, tuple[tuple[Direction, ...], ...]] = {
    TileKind.A: ((Direction.N, Direction.E), (Direction.S, Direction.W)),
    TileKind.B: ((Direction.N, Direction.W), (Direction.S, Direction.E)),
    TileKind.C: (),
    TileKind.D: ((Direction.N, Direction.E, Direction.S, Direction.W),),
}


def new_game() -> GameState:
    board = [[None for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]
    board[SL[0]][SL[1]] = TileKind.D
    board[EL[0]][EL[1]] = TileKind.D
    return GameState(
        board=_freeze_board(board),
        current_player=Player.MAKER,
        maker_turn_count=0,
        diverter_turn_count=0,
    )


def legal_actions(state: GameState) -> list[Action]:
    if winner(state) is not None:
        return []

    actions: list[Action] = []
    tile = forced_tile_for_current_player(state)
    sl_ports = _reachable_ports_from_sl(state.board)
    for row in range(BOARD_SIZE):
        for col in range(BOARD_SIZE):
            if state.board[row][col] is None and _placement_touches_sl_component(
                state.board, (row, col), tile, sl_ports
            ):
                actions.append(Action(row, col))
    return actions


def apply_action(state: GameState, action: Action) -> GameState:
    if not _inside_board(action.coord):
        raise ValueError(f"Coordinate {action.coord} is outside the board.")
    if state.board[action.row][action.col] is not None:
        raise ValueError(f"Cell {action.coord} is already occupied.")
    if action not in legal_actions(state):
        raise ValueError(f"Move at {action.coord} is not legal.")

    tile = forced_tile_for_current_player(state)
    mutable = [list(row) for row in state.board]
    mutable[action.row][action.col] = tile

    maker_turn_count = state.maker_turn_count
    diverter_turn_count = state.diverter_turn_count
    if state.current_player is Player.MAKER:
        maker_turn_count += 1
        next_player = Player.DIVERTER
    else:
        diverter_turn_count += 1
        next_player = Player.MAKER

    return GameState(
        board=_freeze_board(mutable),
        current_player=next_player,
        maker_turn_count=maker_turn_count,
        diverter_turn_count=diverter_turn_count,
    )


def winner(state: GameState) -> Winner | None:
    if _is_connected_to_sl(state.board, EL):
        return Winner.MAKER
    if _board_full(state.board):
        return Winner.DIVERTER
    if not legal_actions_without_terminal_check(state):
        return Winner.DIVERTER
    return None


def is_terminal(state: GameState) -> bool:
    return winner(state) is not None


def forced_tile_for_current_player(state: GameState) -> TileKind:
    if state.current_player is Player.MAKER:
        return MAKER_CYCLE[state.maker_turn_count % len(MAKER_CYCLE)]
    return DIVERTER_CYCLE[state.diverter_turn_count % len(DIVERTER_CYCLE)]


def legal_actions_without_terminal_check(state: GameState) -> list[Action]:
    actions: list[Action] = []
    tile = forced_tile_for_current_player(state)
    sl_ports = _reachable_ports_from_sl(state.board)
    for row in range(BOARD_SIZE):
        for col in range(BOARD_SIZE):
            if state.board[row][col] is None and _placement_touches_sl_component(
                state.board, (row, col), tile, sl_ports
            ):
                actions.append(Action(row, col))
    return actions


def open_ports(tile: TileKind) -> frozenset[Direction]:
    return ALL_PORTS


def connected_ports(tile: TileKind, entry: Direction) -> frozenset[Direction]:
    connected: set[Direction] = set()
    for group in TILE_CONNECTIONS[tile]:
        if entry in group:
            connected.update(group)
    return frozenset(connected)


def neighbor(coord: Coord, direction: Direction) -> Coord:
    row, col = coord
    dr, dc = OFFSETS[direction]
    return ((row + dr) % BOARD_SIZE, (col + dc) % BOARD_SIZE)


def _freeze_board(rows: Iterable[Iterable[TileKind | None]]) -> Board:
    return tuple(tuple(row) for row in rows)


def _inside_board(coord: Coord) -> bool:
    row, col = coord
    return 0 <= row < BOARD_SIZE and 0 <= col < BOARD_SIZE


def _board_full(board: Board) -> bool:
    return all(tile is not None for row in board for tile in row)


def _placement_touches_sl_component(
    board: Board,
    coord: Coord,
    tile: TileKind,
    sl_ports: frozenset[tuple[Coord, Direction]],
) -> bool:
    for direction in open_ports(tile):
        other_coord = neighbor(coord, direction)
        other_tile = board[other_coord[0]][other_coord[1]]
        if other_tile is None:
            continue
        other_port = OPPOSITE[direction]
        if other_port in open_ports(other_tile) and (other_coord, other_port) in sl_ports:
            return True
    return False


def _is_connected_to_sl(board: Board, coord: Coord) -> bool:
    tile = board[coord[0]][coord[1]]
    if tile is None:
        return False
    reachable_ports = _reachable_ports_from_sl(board)
    return any((coord, port) in reachable_ports for port in open_ports(tile))


def _reachable_ports_from_sl(board: Board) -> frozenset[tuple[Coord, Direction]]:
    start_tile = board[SL[0]][SL[1]]
    if start_tile is None:
        return frozenset()

    start_ports = [(SL, port) for port in open_ports(start_tile)]
    queue: deque[tuple[Coord, Direction]] = deque(start_ports)
    visited = set(start_ports)

    while queue:
        coord, port = queue.popleft()
        tile = board[coord[0]][coord[1]]
        if tile is None:
            continue

        for exit_port in connected_ports(tile, port):
            if (coord, exit_port) not in visited:
                visited.add((coord, exit_port))
                queue.append((coord, exit_port))

            other_coord = neighbor(coord, exit_port)
            other_tile = board[other_coord[0]][other_coord[1]]
            if other_tile is None:
                continue
            other_port = OPPOSITE[exit_port]
            if other_port in open_ports(other_tile) and (other_coord, other_port) not in visited:
                visited.add((other_coord, other_port))
                queue.append((other_coord, other_port))

    return frozenset(visited)

