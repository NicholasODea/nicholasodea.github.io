from __future__ import annotations

import asyncio
import platform
import sys
import traceback
from dataclasses import dataclass

import pygame

from pathgame.core import (
    BOARD_SIZE,
    DIVERTER_CYCLE,
    EL,
    MAKER_CYCLE,
    SL,
    Action,
    GameState,
    Player,
    TileKind,
    Winner,
    apply_action,
    forced_tile_for_current_player,
    is_terminal,
    legal_actions,
    new_game,
    winner,
)
from pathgame.graphics import BG, TEXT, TILE_BG, TILE_EDGE, make_tile_surface


WINDOW_SIZE = (920, 660)
BOARD_ORIGIN = (80, 92)
CELL_SIZE = 82
GAP = 0  # Tile surfaces fill the grid pitch; no backing squares or gutters.
PANEL_X = 620
ACCENT = (29, 120, 132)
MAKER_COLOR = (36, 96, 160)
DIVERTER_COLOR = (164, 72, 57)
GRID_LINE = (83, 87, 94)
EMPTY_CELL = (232, 228, 218)
ILLEGAL = (176, 55, 48)
OK = (50, 128, 72)
MUTED = (99, 105, 115)
PANEL = (255, 252, 244)
HIGHLIGHT = (126, 66, 195)  # Purple outline around the upcoming tile
PREVIOUS = (126, 102, 181)
ERROR_BG = (42, 45, 52)
ERROR_TEXT = (255, 235, 220)


def _running_in_browser() -> bool:
    return platform.system() == "Emscripten" or sys.platform in {"emscripten", "wasm32"}


@dataclass(frozen=True)
class MoveRecord:
    move_number: int
    player: Player
    tile: TileKind
    coordinate: tuple[int, int]
    state_before: GameState
    state_after: GameState


class PathsApp:
    def __init__(self) -> None:
        pygame.init()
        pygame.display.set_caption("Paths")
        self.screen = pygame.display.set_mode(WINDOW_SIZE)
        self.clock = pygame.time.Clock()
        self._draw_startup_marker("Starting Paths...")
        self.font = pygame.font.Font(None, 28)
        self.small_font = pygame.font.Font(None, 22)
        self.large_font = pygame.font.Font(None, 44)
        self.state = new_game()
        self.history: list[MoveRecord] = []
        self.message = "Maker starts. Click a legal empty cell."
        self.message_color = TEXT
        self.tile_cache: dict[tuple[TileKind, int, str | None, bool], pygame.Surface] = {}
        self.control_rects: dict[str, pygame.Rect] = {}
        self._draw()
        pygame.display.flip()

    def _draw_startup_marker(self, message: str) -> None:
        self.screen.fill(BG)
        pygame.draw.rect(self.screen, ACCENT, pygame.Rect(72, 72, 360, 90), width=4)
        try:
            font = pygame.font.Font(None, 32)
            text = font.render(message, True, TEXT)
            self.screen.blit(text, (96, 104))
        except Exception:
            pygame.draw.rect(self.screen, TEXT, pygame.Rect(96, 104, 160, 18))
        pygame.display.flip()

    async def run_async(self) -> None:
        running = True
        try:
            while running:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False
                    elif event.type == pygame.KEYDOWN:
                        running = self._handle_key(event.key)
                    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                        running = self._handle_click(event.pos)

                self._draw()
                pygame.display.flip()
                self.clock.tick(60)
                await asyncio.sleep(0)
        except Exception as exc:
            traceback.print_exc()
            await self._show_exception(exc)
        finally:
            if not _running_in_browser():
                pygame.quit()

    def run(self) -> None:
        asyncio.run(run_async())

    def _handle_key(self, key: int) -> bool:
        if key in (pygame.K_q, pygame.K_ESCAPE):
            return False
        if key == pygame.K_r:
            self._reset()
        elif key == pygame.K_z:
            self._undo()
        return True

    def _reset(self) -> None:
        self.state = new_game()
        self.history.clear()
        self.message = "Game reset. Maker starts."
        self.message_color = TEXT

    def _undo(self) -> None:
        if not self.history:
            self.message = "No moves to undo."
            self.message_color = ILLEGAL
            return
        record = self.history.pop()
        self.state = record.state_before
        row, col = record.coordinate
        self.message = f"Undid move {record.move_number}: {record.player.value} {record.tile.value} at ({row}, {col})."
        self.message_color = TEXT

    def _handle_click(self, pos: tuple[int, int]) -> bool:
        # Controls take priority and work regardless of whether the game is over.
        for command, rect in self.control_rects.items():
            if rect.collidepoint(pos):
                if command == "undo":
                    self._undo()
                elif command == "reset":
                    self._reset()
                elif command == "quit":
                    return False
                return True
        coord = self._coord_from_pos(pos)
        if coord is None:
            return True
        row, col = coord
        action = Action(row, col)

        if is_terminal(self.state):
            self.message = "The game is over. Press r to reset or z to undo."
            self.message_color = ILLEGAL
            return True
        if self.state.board[row][col] is not None:
            self.message = f"Cell ({row}, {col}) is already occupied."
            self.message_color = ILLEGAL
            return True

        legal = set(legal_actions(self.state))
        if action not in legal:
            tile = forced_tile_for_current_player(self.state)
            self.message = f"{tile.value} at ({row}, {col}) must connect to the SL component."
            self.message_color = ILLEGAL
            return True

        before = self.state
        player = before.current_player
        tile = forced_tile_for_current_player(before)
        after = apply_action(before, action)
        self.state = after
        self.history.append(
            MoveRecord(
                move_number=len(self.history) + 1,
                player=player,
                tile=tile,
                coordinate=coord,
                state_before=before,
                state_after=after,
            )
        )
        self._set_success_message(player, tile, coord)
        return True

    def _set_success_message(self, player: Player, tile: TileKind, coord: tuple[int, int]) -> None:
        row, col = coord
        game_winner = winner(self.state)
        if game_winner is Winner.MAKER:
            self.message = f"Maker wins! {tile.value} at ({row}, {col}) connects SL to EL."
            self.message_color = OK
        elif game_winner is Winner.DIVERTER:
            self.message = "Diverter wins! Maker has no completed path."
            self.message_color = DIVERTER_COLOR
        else:
            next_tile = forced_tile_for_current_player(self.state)
            self.message = f"{player.value} placed {tile.value} at ({row}, {col}). Next: {self.state.current_player.value} {next_tile.value}."
            self.message_color = TEXT

    def _coord_from_pos(self, pos: tuple[int, int]) -> tuple[int, int] | None:
        x, y = pos
        ox, oy = BOARD_ORIGIN
        board_span = BOARD_SIZE * CELL_SIZE
        if not (ox <= x < ox + board_span and oy <= y < oy + board_span):
            return None
        col = (x - ox) // CELL_SIZE
        row = (y - oy) // CELL_SIZE
        return (int(row), int(col))

    def _draw(self) -> None:
        self.screen.fill(BG)
        self._draw_title()
        self._draw_board()
        self._draw_panel()
        self._draw_message()

    def _draw_title(self) -> None:
        title = self.large_font.render("Paths", True, TEXT)
        self.screen.blit(title, (78, 28))
        subtitle = self.small_font.render("6 x 6 torus tile-placement game", True, MUTED)
        self.screen.blit(subtitle, (190, 42))

    def _draw_board(self) -> None:
        ox, oy = BOARD_ORIGIN
        span = BOARD_SIZE * CELL_SIZE
        # The outermost four corners are square, just like every other cell.
        # Neutral cream for unoccupied cells, with light blue reserved
        # exclusively for empty locations permitted by the current rules.
        EMPTY_BLUE = (218, 235, 245)
        pygame.draw.rect(self.screen, TILE_BG, (ox, oy, span, span))
        for action in legal_actions(self.state):
            x = ox + action.col * CELL_SIZE
            y = oy + action.row * CELL_SIZE
            pygame.draw.rect(self.screen, EMPTY_BLUE, (x, y, CELL_SIZE, CELL_SIZE))

        for i in range(BOARD_SIZE):
            col_label = self.font.render(str(i), True, TEXT)
            self.screen.blit(col_label, col_label.get_rect(center=(ox + i * CELL_SIZE + CELL_SIZE // 2, oy - 24)))
            row_label = self.font.render(str(i), True, TEXT)
            self.screen.blit(row_label, row_label.get_rect(center=(ox - 24, oy + i * CELL_SIZE + CELL_SIZE // 2)))

        for row in range(BOARD_SIZE):
            for col in range(BOARD_SIZE):
                tile = self.state.board[row][col]
                if tile is None:
                    continue
                x, y = ox + col * CELL_SIZE, oy + row * CELL_SIZE
                label = "S" if (row, col) == SL else "E" if (row, col) == EL else None
                self.screen.blit(self._tile(tile, CELL_SIZE, label, show_frame=False), (x, y))

        # Draw all cell lines exactly once. Same charcoal on both empty and
        # occupied squares, so no doubled or separated borders.
        edge_width = 3
        for i in range(1, BOARD_SIZE):
            x = ox + i * CELL_SIZE
            y = oy + i * CELL_SIZE
            pygame.draw.line(self.screen, TILE_EDGE, (x, oy), (x, oy + span), edge_width)
            pygame.draw.line(self.screen, TILE_EDGE, (ox, y), (ox + span, y), edge_width)

        pygame.draw.rect(self.screen, TILE_EDGE,
                         pygame.Rect(ox, oy, span, span), width=edge_width)

    def _draw_panel(self) -> None:
        panel_rect = pygame.Rect(PANEL_X, 70, 250, 500)
        pygame.draw.rect(self.screen, PANEL, panel_rect, border_radius=8)
        pygame.draw.rect(self.screen, (185, 180, 168), panel_rect, width=2, border_radius=8)

        self._draw_info_line("Current Player", self.state.current_player.value, 92)
        self._draw_cycle("Maker", MAKER_CYCLE, self.state.maker_turn_count, Player.MAKER, 164)
        self._draw_cycle("Diverter", DIVERTER_CYCLE, self.state.diverter_turn_count, Player.DIVERTER, 271)
        self._draw_previous_tile(382)
        self._draw_controls(490)

    def _draw_info_line(self, label: str, value: str, y: int) -> None:
        label_surface = self.small_font.render(label, True, MUTED)
        value_surface = self.font.render(value, True, TEXT)
        self.screen.blit(label_surface, (PANEL_X + 22, y))
        self.screen.blit(value_surface, (PANEL_X + 22, y + 24))

    def _draw_previous_tile(self, y: int) -> None:
        label = self.small_font.render("Previous tile", True, MUTED)
        self.screen.blit(label, (PANEL_X + 22, y))
        if self.history:
            record = self.history[-1]
            surface = self._tile(record.tile, 46)
            self.screen.blit(surface, (PANEL_X + 22, y + 24))
            row, col = record.coordinate
            value = f"{record.player.value} at ({row}, {col})"
            text = self.small_font.render(value, True, TEXT)
            self.screen.blit(text, (PANEL_X + 82, y + 27))
            tile_text = self.font.render(record.tile.value, True, TEXT)
            self.screen.blit(tile_text, (PANEL_X + 82, y + 48))
        else:
            value = "None"
            surface = self.font.render(value, True, TEXT)
            self.screen.blit(surface, (PANEL_X + 22, y + 28))

    def _draw_cycle(
        self,
        label: str,
        cycle: tuple[TileKind, ...],
        turn_count: int,
        player: Player,
        y: int,
    ) -> None:
        color = MAKER_COLOR if player is Player.MAKER else DIVERTER_COLOR
        title = self.font.render(label, True, color)
        self.screen.blit(title, (PANEL_X + 22, y))
        current_index = turn_count % len(cycle)
        x = PANEL_X + 20
        tile_size = 36
        step = 42
        for index, tile in enumerate(cycle):
            rect = pygame.Rect(x + index * step, y + 34, tile_size, tile_size)
            # Use the full-size square tile directly, without an extra rounded
            # square behind it. Identical outlines and paths to the board.
            surface = self._tile(tile, tile_size)
            self.screen.blit(surface, rect.topleft)
            if self.state.current_player is player and index == current_index and not is_terminal(self.state):
                # Outside the frame: highlight the exact tile to be played next,
                # leaving the tile's own charcoal border and ports unobscured.
                pygame.draw.rect(self.screen, HIGHLIGHT, rect.inflate(8, 8), width=3)

    def _draw_controls(self, y: int) -> None:
        self.control_rects.clear()
        controls = (("undo", "Undo", "Z"), ("reset", "Reset", "R"), ("quit", "Quit", "Q"))
        for index, (command, title, shortcut) in enumerate(controls):
            rect = pygame.Rect(PANEL_X + 20 + index * 76, y, 68, 47)
            self.control_rects[command] = rect
            pygame.draw.rect(self.screen, (244, 242, 236), rect, border_radius=5)
            pygame.draw.rect(self.screen, TILE_EDGE, rect, width=2, border_radius=5)
            title_surface = self.small_font.render(title, True, TEXT)
            hint_surface = self.small_font.render(shortcut, True, MUTED)
            self.screen.blit(title_surface, title_surface.get_rect(center=(rect.centerx, rect.y + 15)))
            self.screen.blit(hint_surface, hint_surface.get_rect(center=(rect.centerx, rect.y + 34)))

    def _draw_message(self) -> None:
        rect = pygame.Rect(78, 600, 792, 40)
        pygame.draw.rect(self.screen, (255, 252, 244), rect, border_radius=8)
        pygame.draw.rect(self.screen, ACCENT, rect, width=2, border_radius=8)
        surface = self.font.render(self.message, True, self.message_color)
        self.screen.blit(surface, surface.get_rect(midleft=(rect.x + 16, rect.centery)))

    async def _show_exception(self, exc: Exception) -> None:
        lines = traceback.format_exception_only(type(exc), exc)
        message = "".join(lines).strip() or repr(exc)
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return
                if event.type == pygame.KEYDOWN and event.key in (pygame.K_q, pygame.K_ESCAPE):
                    return

            self.screen.fill(ERROR_BG)
            title = self.large_font.render("Paths crashed", True, ERROR_TEXT)
            self.screen.blit(title, (72, 72))
            body = self.font.render(message[:100], True, ERROR_TEXT)
            self.screen.blit(body, (72, 132))
            hint = self.small_font.render("See the browser console or terminal for the full traceback.", True, ERROR_TEXT)
            self.screen.blit(hint, (72, 176))
            pygame.display.flip()
            self.clock.tick(30)
            await asyncio.sleep(0)

    def _tile(self, tile: TileKind, size: int, label: str | None = None, show_frame: bool = True) -> pygame.Surface:
        key = (tile, size, label, show_frame)
        if key not in self.tile_cache:
            self.tile_cache[key] = make_tile_surface(tile, size, label, show_frame)
        return self.tile_cache[key]


def run() -> None:
    PathsApp().run()


async def run_async() -> None:
    try:
        await PathsApp().run_async()
    except Exception as exc:
        traceback.print_exc()
        await _show_startup_exception(exc)


async def _show_startup_exception(exc: Exception) -> None:
    pygame.init()
    screen = pygame.display.set_mode(WINDOW_SIZE)
    clock = pygame.time.Clock()
    message = "".join(traceback.format_exception_only(type(exc), exc)).strip() or repr(exc)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                if not _running_in_browser():
                    pygame.quit()
                return
            if event.type == pygame.KEYDOWN and event.key in (pygame.K_q, pygame.K_ESCAPE):
                if not _running_in_browser():
                    pygame.quit()
                return

        screen.fill(ERROR_BG)
        pygame.draw.rect(screen, ERROR_TEXT, pygame.Rect(72, 72, 520, 150), width=4)
        try:
            font = pygame.font.Font(None, 30)
            large_font = pygame.font.Font(None, 46)
            title = large_font.render("Paths failed to start", True, ERROR_TEXT)
            screen.blit(title, (96, 96))
            body = font.render(message[:100], True, ERROR_TEXT)
            screen.blit(body, (96, 156))
        except Exception:
            pygame.draw.rect(screen, ERROR_TEXT, pygame.Rect(96, 96, 260, 24))
            pygame.draw.rect(screen, ERROR_TEXT, pygame.Rect(96, 156, 420, 18))
        pygame.display.flip()
        clock.tick(30)
        await asyncio.sleep(0)
