"""Procedurally drawn, supersampled angular tiles for Paths."""
from __future__ import annotations

import math
import pygame
from pathgame.core import TileKind

BG = (246, 244, 239)
TILE_BG = (255, 252, 244)
TILE_EDGE = (39, 47, 52)
PATH = (15, 123, 132)
TEXT = (30, 34, 40)
STUB = (214, 54, 62)


def tile_shapes(tile_kind: TileKind, size: int):
    """Return polygon geometry in logical tile pixels; usable by any renderer."""
    c = size / 2
    w = size * 0.115
    elbow = size * 0.275
    # Centerline through a 45-degree segment; miter joins are explicit polygons.
    def ribbon(points):
        dirs = []
        normals = []
        for a, b in zip(points, points[1:]):
            dx, dy = b[0] - a[0], b[1] - a[1]
            length = math.hypot(dx, dy)
            dx, dy = dx / length, dy / length
            dirs.append((dx, dy))
            normals.append((-dy, dx))
        offsets = []
        for i in range(len(points)):
            if i == 0:
                n = normals[0]
                offsets.append((n[0] * w / 2, n[1] * w / 2))
            elif i == len(points) - 1:
                n = normals[-1]
                offsets.append((n[0] * w / 2, n[1] * w / 2))
            else:
                a, b = normals[i-1], normals[i]
                sum_n = (a[0] + b[0], a[1] + b[1])
                factor = (w / 2) / (1 + a[0]*b[0] + a[1]*b[1])
                offsets.append((sum_n[0]*factor, sum_n[1]*factor))
        return ([(p[0]+o[0], p[1]+o[1]) for p,o in zip(points, offsets)] +
                [(p[0]-o[0], p[1]-o[1]) for p,o in reversed(list(zip(points, offsets)))])

    polys = []
    if tile_kind is TileKind.A:
        polys = [ribbon([(c, 0), (c, elbow), (size-elbow, c), (size,c)]),
                 ribbon([(c, size), (c, size-elbow), (elbow,c), (0,c)])]
    elif tile_kind is TileKind.B:
        polys = [ribbon([(c, 0), (c, elbow), (elbow,c), (0,c)]),
                 ribbon([(c, size), (c, size-elbow), (size-elbow,c), (size,c)])]
    elif tile_kind is TileKind.C:
        # Each triangle's base is exactly w wide, with NO outward flare.
        tip = size * 0.355
        base = tip - w * 0.65
        polys = [
            [(c-w/2, 0), (c+w/2, 0), (c+w/2, base), (c,tip), (c-w/2,base)],
            [(size, c-w/2), (size,c+w/2), (size-base,c+w/2), (size-tip,c), (size-base,c-w/2)],
            [(c+w/2,size), (c-w/2,size), (c-w/2,size-base), (c,size-tip), (c+w/2,size-base)],
            [(0,c+w/2), (0,c-w/2), (base,c-w/2), (tip,c), (base,c+w/2)],
        ]
    elif tile_kind is TileKind.D:
        polys = [ribbon([(c, 0), (c,size)]), ribbon([(0,c),(size,c)])]
    return polys


def make_tile_surface(tile_kind: TileKind, size: int, label: str | None = None, show_frame: bool = True) -> pygame.Surface:
    # Supersampling also works on the small cycle tiles in the sidebar.
    scale = 4
    s = size * scale
    surface = pygame.Surface((s,s), pygame.SRCALPHA)
    surface.fill(TILE_BG)
    def coords(poly):
        return [(round(x*scale), round(y*scale)) for x,y in poly]
    # Draw the paths beneath the frame, so each port joins the midpoint neatly.
    for poly in tile_shapes(tile_kind, size):
        pygame.draw.polygon(surface, STUB if tile_kind is TileKind.C else PATH, coords(poly))

    # Identical square perimeter to the shared black lines on the board.
    # At sidebar sizes the stroke is scaled proportionally from 3 px / 82 px.
    if show_frame:
        border_width = max(1, round(size * (3 / 82) * scale))
        # Paint a flush perimeter, including the outermost pixels. A centered
        # pygame.rect stroke leaves path pixels showing outside its outline
        # when this small preview is downsampled.
        pygame.draw.rect(surface, TILE_EDGE,
                         pygame.Rect(0, 0, s, s), width=border_width)
    if label:
        font = pygame.font.Font(None, round(size * 0.48 * scale))
        glyph = font.render(label, True, TEXT)
        # The font surface has asymmetric invisible ascender/descender space.
        # Center the actual painted glyph, not the entire font surface.
        visible = glyph.get_bounding_rect()
        center_x = s // 2
        center_y = s // 2
        text_pos = (center_x - visible.centerx, center_y - visible.centery)
        pad = round(size * .07 * scale)
        badge = pygame.Rect(0, 0, visible.width + pad * 2,
                            visible.height + pad * 2)
        badge.center = (center_x, center_y)
        pygame.draw.rect(surface, TILE_BG, badge, border_radius=max(1,pad//2))
        pygame.draw.rect(surface, TILE_EDGE, badge,
                         width=max(1, round(size * .018 * scale)),
                         border_radius=max(1,pad//2))
        surface.blit(glyph, text_pos)
    return pygame.transform.smoothscale(surface, (size,size))
